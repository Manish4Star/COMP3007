COMP 3007 - Assignment 2 - Due Date February 22, 2016
Authors: Abdul Bin Asif Niazi 10091719

GENERAL USAGE NOTES
------------------------------------
- All files ending with .rkt will run in DrRacket
- .rkt files are written is Scheme using R5RS version of Scheme
- In language options, the initial bindings box is left unchecked
----------------------------------------------------------------------------------------------------------------------------

run files in DrRacket
-----------------------------------------
- open each file in DrRacket
- click 'Determine Language from Source' on the bottom right, opening a drop down menu
- click the 'Choose Language option'
- select the 'Other Languages' radio button, this will cause the choose language box to expand
- unselect 'Disallow redefinition of initial bindings' under the Initial Bindings heading
- double click on R5RS on the left side under other languages
- click ok to close the choose language box
- click run on the top right to run the test cases
- functions can be called in the interpreter/console to test different inputs
----------------------------------------------------------------------------------------------------------------------------