﻿COMP 3007 - Assignment 4 - Due Date April 4, 2016
Authors: Abdul Bin Asif Niazi 10091719

GENERAL USAGE NOTES
------------------------------------
- All files ending with .pl will run in SWI-PROLOG
- .pl files are the source files for Prolog
----------------------------------------------------------------------------------------------------------------------------

run files in SWI-Prolog
-----------------------------------------
- open SWI-Prolog
- click file->consult
- the open box, navigate to the .pl file and double click on it
- once open the facts have been loaded and queries can be made to the database
----------------------------------------------------------------------------------------------------------------------------
